using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Prog5_1C_2K26.Models;

namespace Prog5_1C_2K26.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        #region Suma2

        public IActionResult Suma2()
        {
            return View();
        }

        public IActionResult add2()
        {
            try
            {
                int num1 = Convert.ToInt32(HttpContext.Request.Form["tx1"].ToString());
                int num2 = Convert.ToInt32(HttpContext.Request.Form["tx2"].ToString());

                int result = num1 + num2;

                ViewBag.SumResult2 = result.ToString();
            }
            catch (Exception)
            {
                ViewBag.SumResult2 = "Datos incorrectos";
            }

            return View("Suma2");
        }

        #endregion Suma2


        #region Calculadora basica

        public IActionResult bCalc()
        {
            return View();
        }

        // ================== SUMA ==================

        [HttpPost]
        public IActionResult Suma()
        {
            try
            {
                int num1 = Convert.ToInt32(HttpContext.Request.Form["n1"]);
                int num2 = Convert.ToInt32(HttpContext.Request.Form["n2"]);

                int resultado = num1 + num2;

                ViewBag.Result = "Resultado de la suma: " + resultado;
            }
            catch (Exception)
            {
                ViewBag.Result = "Error: Datos err�neos";
            }

            return View("bCalc");
        }


        // ================== RESTA ==================

        [HttpPost]
        public IActionResult Resta()
        {
            try
            {
                int num1 = Convert.ToInt32(HttpContext.Request.Form["n1"]);
                int num2 = Convert.ToInt32(HttpContext.Request.Form["n2"]);

                int resultado = num1 - num2;

                ViewBag.Result = "Resultado de la resta: " + resultado;
            }
            catch (Exception)
            {
                ViewBag.Result = "Error: Datos err�neos";
            }

            return View("bCalc");
        }


        // ================== MULTIPLICACION ==================

        [HttpPost]
        public IActionResult Multiplicacion()
        {
            try
            {
                int num1 = Convert.ToInt32(HttpContext.Request.Form["n1"]);
                int num2 = Convert.ToInt32(HttpContext.Request.Form["n2"]);

                int resultado = num1 * num2;

                ViewBag.Result = "Resultado de la multiplicaci�n: " + resultado;
            }
            catch (Exception)
            {
                ViewBag.Result = "Error: Datos err�neos";
            }

            return View("bCalc");
        }


        // ================== DIVISION ==================

        [HttpPost]
        public IActionResult Division()
        {
            try
            {
                decimal num1 = Convert.ToDecimal(HttpContext.Request.Form["n1"]);
                decimal num2 = Convert.ToDecimal(HttpContext.Request.Form["n2"]);

                if (num2 == 0)
                    throw new Exception("No se puede dividir entre cero");

                decimal resultado = num1 / num2;

                ViewBag.Result = "Resultado de la divisi�n: " + resultado;
            }
            catch (Exception ex)
            {
                ViewBag.Result = "Error: " + ex.Message;
            }

            return View("bCalc");
        }


        // ================== MODULO ==================

        [HttpPost]
        public IActionResult Modulo()
        {
            try
            {
                int num1 = Convert.ToInt32(HttpContext.Request.Form["n1"]);
                int num2 = Convert.ToInt32(HttpContext.Request.Form["n2"]);

                if (num2 == 0)
                    throw new Exception("No se puede calcular m�dulo con cero");

                int resultado = num1 % num2;

                ViewBag.Result = "Resultado del m�dulo: " + resultado;
            }
            catch (Exception ex)
            {
                ViewBag.Result = "Error: " + ex.Message;
            }

            return View("bCalc");
        }


        // ================== RAIZ ==================

        [HttpPost]
        public IActionResult Raiz()
        {
            try
            {
                double num1 = Convert.ToDouble(HttpContext.Request.Form["n1"]);

                if (num1 < 0)
                    throw new Exception("No se permite ra�z negativa");

                double resultado = Math.Sqrt(num1);

                ViewBag.Result = "Resultado de la ra�z: " + resultado;
            }
            catch (Exception ex)
            {
                ViewBag.Result = "Error: " + ex.Message;
            }

            return View("bCalc");
        }


        // ================== POTENCIA ==================

        [HttpPost]
        public IActionResult Potencia()
        {
            try
            {
                double num1 = Convert.ToDouble(HttpContext.Request.Form["n1"]);
                double num2 = Convert.ToDouble(HttpContext.Request.Form["n2"]);

                double resultado = Math.Pow(num1, num2);

                ViewBag.Result = "Resultado de la potencia: " + resultado;
            }
            catch (Exception ex)
            {
                ViewBag.Result = "Error: " + ex.Message;
            }

            return View("bCalc");
        }

        #endregion Calculadora basica


        public IActionResult Privacy()
        {
            return View();
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel
            {
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
            });
        }
    }
}
